#include <string>
#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char*argv[]) {
	fstream f (argv[1]);
	string line;
	while (getline (f, line)) {
		cout << "[" << line << "]" << endl;
}
}
