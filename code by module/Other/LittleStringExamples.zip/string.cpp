#include <string>
#include <iostream>
using namespace std;

int main()
{
   string s = "hello";
   string t = s;

   t[0] = 'j';
   cout << "s = " << s << endl;
   cout << "t = " << t << endl;
}
