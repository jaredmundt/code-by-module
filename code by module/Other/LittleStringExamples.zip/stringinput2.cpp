#include <string>
#include <iostream>
#include <fstream>
using namespace std;

int main() {
	string word;
	while (true) {
		cin >> word;
		cout << "[" << word << "]" << endl;
		if (cin.eof() )
			break;
	}
}
// try with a < words.txt
