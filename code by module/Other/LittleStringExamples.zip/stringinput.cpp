#include <string>
#include <iostream>
using namespace std;

int main() {
	string word;
	while (cin >> word)
		cout << "[" << word << "]" << endl;
}
