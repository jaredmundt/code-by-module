#include <string>
#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char*argv[]) {
	fstream f (argv[1]);
	string line;
	//while (getline (cin, line))
	while (true) {
		getline (f, line);
		cout << "[" << line << "]" << endl;
		if (f.eof() == true)
			break;
	}
}
